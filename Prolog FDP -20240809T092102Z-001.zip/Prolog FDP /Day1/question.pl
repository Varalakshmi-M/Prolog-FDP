midponits(X1,Y1,X2,Y2):-
	M1 is (X1+X2)/2,
	M2 is (Y1+Y2)/2,
	write('Binoy\'s house is located at ('),write(M1),write(','), write(M2),write(')').