condition(A,B):-
	A>B,
	write('A is greater than B').