powerstar(A,B):-
	P is A**B,
	write(P).

summore(A,B,C):-
	Sum is A+B+C,
	write(Sum).

