likes(ram,mango).
likes(bill,cindey).
girl(seema).
toad(rose).
owns(john, gold).