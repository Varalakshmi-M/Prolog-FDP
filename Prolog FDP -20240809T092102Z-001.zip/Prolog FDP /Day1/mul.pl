mul(A,B):-
	Res is A*B,
	write(Res).
