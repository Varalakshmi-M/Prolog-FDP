likes(ram, seeta).
likes(ravi, razi).