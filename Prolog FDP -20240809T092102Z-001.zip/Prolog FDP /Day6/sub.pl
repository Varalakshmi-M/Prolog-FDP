sub(A,B):-
	S is A-B,
	write(S).