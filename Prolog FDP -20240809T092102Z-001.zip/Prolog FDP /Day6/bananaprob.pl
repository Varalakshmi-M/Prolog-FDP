move(state(P1,onfloor,Chair,Have),
	walk(P1,P2),
	state(P2,onfloor,Chair,Have)).

move(state(P1,onfloor,P1,Have),
	push(P1,P2),
	state(P2,onfloor,P2,Have)).

move(state(P2,onfloor,P2,Have),
	climb,
	state(P2,onchair,P2,Have)).

move(state(middle,onchair,middle,hasnot),
	grab,
	state(middle,onchair,middle,has)).
canget(state(_,_,_,has)).
canget(State1):-
	move(State1,_,State2),
	canget(State2).