power(A,B):-
	P is A^B,
	write(P).

