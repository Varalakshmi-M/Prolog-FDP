%create the facts
symptom(cold, [sneezing,headache,runny_nose]).
symptom(flu, [fever,cough,sore_throat]).
symptom(pneumonia, [shortness_of_breath,fever,cough]).
%example to execute: symptom(Disease, [fever,cough,sore_throat]).