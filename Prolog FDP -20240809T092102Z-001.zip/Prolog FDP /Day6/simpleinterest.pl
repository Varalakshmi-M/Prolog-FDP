simple(P,T,R):-
	Int is (P*T*R)/100,
	Dis is (2*Int)/100,
	write(Int),nl,
	write(Dis).