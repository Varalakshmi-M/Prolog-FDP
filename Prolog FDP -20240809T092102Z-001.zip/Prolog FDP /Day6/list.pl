lists(List,Val):-
length(List,N),
write(N),nl,
member(Val,Liast).
