realdiv(A,B):-
	Ans is A/B,
	write(Ans).
