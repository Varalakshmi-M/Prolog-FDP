%create the facts
symptom(cold, runny_nose).
symptom(cold, sneezing).
symptom(cold, headache).
symptom(flu, fever).
symptom(flu, cough).
symptom(flu, sore_throat).
symptom(pneumonia, fever).
symptom(pneumonia, cough).
symptom(pneumonia, shortness_of_breath).

disease(Symtomslist, Disease):-
	setof(What_disease,(symptom(What_disease, Singlesymptom),member(Singlesymptom, Symtomslist)), Diseaselist),
	length(Diseaselist, N),
	N>0,
	write('You my have '), write(Diseaselist), write('.').
disease(_,_):-
	write('jhgkjfhg jhg kdjfghkdfj gk').

%example to execute: disease([sneezing,fever,cough],Disease).
