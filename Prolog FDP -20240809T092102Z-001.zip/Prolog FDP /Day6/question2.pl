ftoc(F):-
	C is 5/9*(F-32),
	write('Fahrenheit:'),
	write(F),nl,
	write('Celsius:'),
	write(C).