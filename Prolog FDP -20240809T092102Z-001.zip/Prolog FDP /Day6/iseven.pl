iseven(A):-
	B is A mod 2,
	B =:= 0,
	write('Given Number is Even Nuber.').