move(1,Source,Destination,_):-
	write('Move top disk from'),
	write(Source),
	write(' to '),
	write(Destination),
	nl.

move(N,Source,Destination,Intermediate):-
	N>1,
	M is N-1,
	move(M,Source,Intermediate,Destination),
	move(1,Intermediate,Destination,Source).